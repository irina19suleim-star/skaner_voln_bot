# -*- coding: utf-8 -*-
import os, time
from flask import Flask, request, abort
import telebot

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "").strip()
if not TELEGRAM_TOKEN:
    raise RuntimeError("Не найден TELEGRAM_TOKEN в переменных окружения.")
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "skanersecret")
HOST_URL = os.getenv("HOST_URL", "")

bot = telebot.TeleBot(TELEGRAM_TOKEN, parse_mode="HTML")
app = Flask(__name__)

GREETING = (
    "💠 <b>Сканер Души</b>\n"
    "Напиши свой запрос (здоровье/деньги/отношения/предназначение)."
)

def build_scan_reply(t: str) -> str:
    t = (t or "").strip() or "Хочу ясности и силы."
    parts = [
        ("Признание",
         [ "Я признаю свой опыт и последствия.",
           f"Я называю свой запрос: «{t}»."]),

        ("Принятие",
         [ "Я принимаю факты без борьбы.",
           "Я даю место всем чувствам и позволяю им проходить."]),

        ("Освобождение",
         [ "Я благодарю уроки и освобождаю чужие роли и договоры.",
           "Я возвращаю своё внимание и энергию себе."]),

        ("Трансформация",
         [ "Я опираюсь на тело и сердце; поле выравнивается.",
           "Я разрешаю себе новый опыт, где ценность выше страха."]),

        ("Выбор нового",
         [ "Я формирую новый вектор ясно и экологично.",
           "Намерение: «Я двигаюсь к результату легко и устойчиво»."]),

        ("Закрепление",
         [ "Закрепляю новые связи ежедневной практикой (5–7 минут).",
           "Подтверждаю выбор маленькими действиями в реальности."]),

        ("Манифестация",
         [ "Я открыта поддержке и вижу сигналы возможностей.",
           "Да будет так. Аминь/Дао/Ом."]),
    ]
    lines = ["✨ <b>Твой маршрут трансформации</b>\n"]
    for i,(title, items) in enumerate(parts, start=1):
        lines.append(f"<b>{i}. {title}</b>")
        lines += [f"• {s}" for s in items]
        lines.append("")
    lines.append("🎧 Трек: тета 5 Гц + 528/639/963 Гц, 15–20 мин ежедневно.")
    lines.append("Команда /практика — короткий ритуал на сегодня.")
    return "\n".join(lines)

DAILY_PRACTICE = (
    "🎯 <b>Практика на сегодня (7 минут)</b>\n"
    "1) 9 спокойных вдохов; выдох длиннее вдоха.\n"
    "2) Ладонь на сердце и низ живота; синхронизируй ритм.\n"
    "3) Формулы: «Благодарю», «Освобождаю», «Выбираю новое».\n"
    "4) Представь золотой поток по позвоночнику; сделай 1 шаг в реальности."
)

@bot.message_handler(commands=['start','help'])
def start(msg):
    bot.reply_to(msg, GREETING)

@bot.message_handler(commands=['practice','практика'])
def practice(msg):
    bot.reply_to(msg, DAILY_PRACTICE)

@bot.message_handler(func=lambda m: True, content_types=['text','photo','voice','audio','document'])
def any_msg(msg):
    text = (getattr(msg,'text',None) or getattr(msg,'caption','') or '').strip()
    bot.reply_to(msg, build_scan_reply(text))

@app.route("/", methods=["GET"])
def home():
    return "Soul Scanner bot up", 200

@app.route("/set_webhook", methods=["GET"])
def set_webhook():
    base_url = HOST_URL or request.url_root.rstrip("/")
    full = f"{base_url}/webhook/{WEBHOOK_SECRET}"
    bot.remove_webhook()
    time.sleep(1)
    ok = bot.set_webhook(url=full, max_connections=1)
    return {"webhook_url": full, "ok": ok}, 200

@app.route("/webhook/<secret>", methods=["POST"])
def webhook(secret):
    if secret != WEBHOOK_SECRET:
        abort(403)
    if request.headers.get("content-type") == "application/json":
        update = telebot.types.Update.de_json(request.get_data().decode("utf-8"))
        bot.process_new_updates([update])
        return "", 200
    abort(400)

if __name__ == "__main__":
    import json
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8000")))
